function [f,Ai,Bi] = oneB(Ps)
Ai=-3
Bi=1
f=Ps^3