function [f,Ai,Bi] = oneC(Ps)
Ai=-pi()/2
Bi=3*pi()/4
f=sin(Ps)