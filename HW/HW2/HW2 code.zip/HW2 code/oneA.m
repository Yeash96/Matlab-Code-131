function [f,Ai,Bi] = oneA(Ps)
Ai=1
Bi=3
f=Ps^3