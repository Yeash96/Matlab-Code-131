function [f,Ai,Bi] = twoBtwo(Ps)
Ai=2
Bi=4
f=Ps^2-4*Ps+4-log(Ps)

  