function [f,Ai,Bi] = threeA(Ps)
Ai=10
Bi=14
f=Ps^3-2016

  