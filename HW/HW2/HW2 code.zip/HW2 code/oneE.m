function [f,Ai,Bi] = oneE(Ps)
Ai=5
Bi=2
if(Ps<2)
  f=0
else
  f=-Ps+3
end
  