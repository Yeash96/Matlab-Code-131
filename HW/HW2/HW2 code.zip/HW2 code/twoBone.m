function [f,Ai,Bi] = twoBone(Ps)
Ai=2
Bi=1
f=Ps^2-4*Ps+4-log(Ps)

  