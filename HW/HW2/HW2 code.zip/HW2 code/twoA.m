function [f,Ai,Bi] = twoA(Ps)
Ai=0
Bi=1
f=2*Ps+3*cos(Ps)-exp(Ps)

  